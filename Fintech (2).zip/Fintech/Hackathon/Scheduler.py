# scheduler_script.py
import schedule
import time
from faysalbank_app_reviews import fetch_playstore_reviews_fb, fetch_appstore_reviews_fb
from meezanbank_app_reviews import fetch_playstore_reviews_meezan, fetch_appstore_reviews_meezan
from soneribank_app_reviews import fetch_playstore_reviews_soneri, fetch_appstore_reviews_soneri
from csv_to_excel import convert_csv_to_excel

# Define the job to fetch, categorize, and convert reviews to Excel
def job():
    # print("Starting job...")
    # print("Fetching Faysal Bank reviews...")
    # print("Fetching Google Play Store reviews...")
    # fetch_playstore_reviews_fb()
    # print("Fetched Google Play Store reviews.")

    # print("Fetching App Store reviews...")
    # fetch_appstore_reviews_fb()
    # print("Fetched App Store reviews.")

    # print("Converting CSV to Excel...")
    # convert_csv_to_excel()
    # print("Conversion to Excel completed.")

    # print("Fetching Meezan Bank reviews...")
    # print("Fetching Google Play Store reviews...")
    # fetch_playstore_reviews_meezan()
    # print("Fetched Google Play Store reviews.")

    # print("Fetching App Store reviews...")
    # fetch_appstore_reviews_meezan()
    # print("Fetched App Store reviews.")

    # print("Converting CSV to Excel...")
    # convert_csv_to_excel()
    # print("Conversion to Excel completed.")

    # print("Fetching Soneri Bank reviews...")
    # print("Fetching Google Play Store reviews...")
    # fetch_playstore_reviews_soneri()
    # print("Fetched Google Play Store reviews.")

    print("Fetching App Store reviews...")
    fetch_appstore_reviews_soneri()
    print("Fetched App Store reviews.")

    print("Converting CSV to Excel...")
    convert_csv_to_excel()
    print("Conversion to Excel completed.")

    print("Job completed.")
    
schedule.clear()

# Schedule the job to run every week (168 hours)
schedule.every(1).minute.do(job)

# Run the scheduler loop
if __name__ == "__main__":
    while True:
        schedule.run_pending()
        time.sleep(60)  # Wait for 60 seconds before checking the schedule again
