import streamlit as st
import pandas as pd
import re
import matplotlib.pyplot as plt
import seaborn as sns
import openai
from pandasai.smart_dataframe import SmartDataframe
from dotenv import load_dotenv
import os
from datetime import datetime, timedelta
import re

# Load environment variables from secret.env file
load_dotenv('secret.env')
openai_api_key = os.getenv('OPENAI_API_KEY')

# Function to clean data in the CSV
def clean_data(df):
    if 'rating' in df.columns:
        df = df.dropna(subset=['rating'])
    else:
        st.warning("No 'rating' column found. Please ensure your CSV includes a 'rating' column.")
        return df

    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].fillna('').apply(preprocess_text)
        elif pd.api.types.is_numeric_dtype(df[col]):
            df[col] = df[col].fillna(0)
    return df

# Text preprocessing function
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    return text

# Function to enhance prompt for concise and focused responses
def enhance_prompt(prompt):
    if "top" in prompt.lower() and "issues" in prompt.lower():
        return f"Identify the top issues from the data based on frequency or severity. Provide a summary with key points."
    elif "trend" in prompt.lower():
        return f"Identify any trends or patterns in the data over time. Provide insights into any shifts in ratings or sentiments."
    elif "sentiment" in prompt.lower():
        return f"Analyze the sentiment distribution in the reviews. Identify the overall sentiment and any notable shifts."
    return prompt

# Function to parse a time range from the user's query
def parse_time_range(query):
    time_range = None
    match = re.search(r'(\d+)\s*(month|week|day)', query.lower())
    if match:
        num = int(match.group(1))
        unit = match.group(2)
        if unit == 'month':
            time_range = timedelta(days=num*30)
        elif unit == 'week':
            time_range = timedelta(weeks=num)
        elif unit == 'day':
            time_range = timedelta(days=num)
    return time_range

# Function to interact with PandasAI
def chat_with_csv(df, prompt):
    llm = OpenAI(api_token=openai_api_key)
    smart_df = SmartDataframe(df)
    result = smart_df.chat(enhance_prompt(prompt))
    return result

# Function to plot trends
def plot_trends(df, date_col, rating_col, time_range=None):
    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
    if time_range:
        cutoff_date = datetime.now() - time_range
        df = df[df[date_col] >= cutoff_date]

    trend_data = df.groupby(df[date_col].dt.to_period("M"))[rating_col].mean().reset_index()
    trend_data[date_col] = trend_data[date_col].dt.to_timestamp()

    plt.figure(figsize=(10, 6))
    sns.lineplot(x=trend_data[date_col], y=trend_data[rating_col], marker='o')
    plt.title(f"Average {rating_col} Over Time", fontsize=16)
    plt.xlabel("Date", fontsize=12)
    plt.ylabel(f"Average {rating_col}", fontsize=12)
    plt.xticks(rotation=45)
    plt.grid(True)
    st.pyplot(plt)

# Function to perform sentiment analysis
def sentiment_analysis(df, sentiment_col='Aspect_Sentiment', time_range=None):
    if time_range:
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        cutoff_date = datetime.now() - time_range
        df = df[df['date'] >= cutoff_date]

    sentiment_counts = df[sentiment_col].value_counts()

    plt.figure(figsize=(8, 5))
    sns.barplot(x=sentiment_counts.index, y=sentiment_counts.values, palette='viridis')
    plt.title(f"Sentiment Distribution", fontsize=16)
    plt.xlabel("Sentiment", fontsize=12)
    plt.ylabel("Frequency", fontsize=12)
    plt.grid(True)
    st.pyplot(plt)

# Streamlit app configuration
st.set_page_config(layout='wide', page_title="ChatCSV powered by LLM", initial_sidebar_state="expanded")

# Updated CSS styles

# Title and introductory text
st.markdown("<h1 class='stTitle'>FaysalBank ChatBot</h1>", unsafe_allow_html=True)
st.write("Enter your query below to interact with the data.")

# File uploader for CSV input
input_csv = st.file_uploader("Upload your CSV file", type=['csv'])

# Ensure CSV data is uploaded and cleaned before allowing interactions
if input_csv is not None:
    data = pd.read_csv(input_csv)
    cleaned_data = clean_data(data)

    # Display cleaned data as a collapsible section
    with st.expander("📊 View Uploaded Data", expanded=False):
        st.dataframe(cleaned_data, use_container_width=True, height=400)

    # Chat interface for queries
    input_text = st.text_area("Query", placeholder="Ask a question about the data (e.g., 'Show average rating of reviews')")

    # Process query only if CSV is uploaded and cleaned
    if input_text and st.button("Chat"):
        st.info("Your Query: " + input_text)
        result = chat_with_csv(cleaned_data, input_text)
        st.success(result)

    # Trend analysis based on user query
    if 'trend' in input_text.lower():
        time_range = parse_time_range(input_text)
        st.subheader("Trend Analysis")
        st.info(f"Plotting trends for the last {time_range.days if time_range else 'all'} days...")
        plot_trends(cleaned_data, 'date', 'rating', time_range)

    # Sentiment analysis based on user query
    if 'sentiment' in input_text.lower():
        time_range = parse_time_range(input_text)
        st.subheader("Sentiment Analysis")
        st.info(f"Plotting sentiment distribution for the last {time_range.days if time_range else 'all'} days...")
        sentiment_analysis(cleaned_data, time_range=time_range)
else:
    st.warning("Please upload a CSV file first.")
