# csv_to_excel.py
import pandas as pd
import os

def convert_csv_to_excel():
    files_to_convert = [
        ('faisal_digibank_playstore_reviews.csv', 'faisal_digibank_playstore_reviews.xlsx'),
        ('faysal_digibank_appstore_reviews.csv', 'faysal_digibank_appstore_reviews.xlsx'),
        ('appstore_word_counts.csv', 'appstore_word_counts.xlsx'),
        ('playstore_word_counts.csv', 'playstore_word_counts.xlsx'),
        ('appstore_sentiment_counts.csv', 'appstore_sentiment_counts.xlsx'),
        ('playstore_sentiment_counts.csv', 'playstore_sentiment_counts.xlsx')
    ]

    for csv_file_path, excel_file_path in files_to_convert:
        if os.path.exists(csv_file_path):
            df = pd.read_csv(csv_file_path)
            df.to_excel(excel_file_path, index=False)
            print(f"Converted {csv_file_path} to {excel_file_path}")
        else:
            print(f"File not found: {csv_file_path}")

convert_csv_to_excel()
