import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.impute import SimpleImputer
from sklearn.compose import make_column_selector

# Load the data
file_path = 'Bank Customer Churn Prediction.csv'
data = pd.read_csv(file_path)

# Display the first few rows and summary information about the data
# data.head(), data.info(), data.describe()

# Drop customer_id as it's likely not useful
data = data.drop(columns=["customer_id"])

# Split data into features (X) and target (y)
X = data.drop(columns=["churn"])
y = data["churn"]

# Define preprocessing for numerical and categorical features
numerical_features = make_column_selector(dtype_include=["int64", "float64"])
categorical_features = make_column_selector(dtype_include="object")

# Preprocessing pipeline
preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), numerical_features),
        ("cat", OneHotEncoder(drop="first"), categorical_features)
    ]
)

# Define the model pipeline
model_pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(random_state=0))
])

# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Train the model
model_pipeline.fit(X_train, y_train)

# Make predictions and evaluate the model
y_pred = model_pipeline.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred)

# print(accuracy)
# print(classification_rep)


# Example: New data in a DataFrame format (it should match the feature structure of X_train)
# new_data = pd.DataFrame({
#     'credit_score': [150],
#     'country': ['France'],
#     'gender': ['Male'],
#     'age': [30],
#     'tenure': [1],
#     'balance': [100000.00],
#     'products_number': [1],
#     'credit_card': [1],
#     'active_member': [1],
#     'estimated_salary': [900000.00]
# })

# # Make prediction using the trained model pipeline
# predicted_churn = model_pipeline.predict(new_data)
# predicted_proba = model_pipeline.predict_proba(new_data)  # Optional: for churn probability

# print("Predicted Churn (1 = Churn, 0 = No Churn):", predicted_churn)
# print("Churn Probability:", predicted_proba[:, 1])  # Probability of churn
