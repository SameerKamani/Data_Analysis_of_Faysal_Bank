import pandas as pd
import random

# Load the existing data
data = pd.read_csv('Bank Customer Churn Prediction.csv')

# Define ranges for each column to generate new data
credit_score_range = (300, 850)
age_range = (18, 90)
tenure_range = (0, 10)
balance_range = (0, 500000)
products_number_range = (1, 6)
estimated_salary_range = (0, 500000)

# Define possible categories
cities = ['Karachi', 'Islamabad', 'Quetta'] 
genders = ['Male', 'Female']
boolean_options = [0, 1]

# Generate 5000 new rows
new_data = []
for _ in range(20000):
    new_row = {
        'customer_id': random.randint(10000000, 99999999),
        'credit_score': random.randint(*credit_score_range),
        'city': random.choice(cities),
        'gender': random.choice(genders),
        'age': random.randint(*age_range),
        'tenure': random.randint(*tenure_range),
        'balance': round(random.uniform(*balance_range), 2),
        'products_number': random.randint(*products_number_range),
        'credit_card': random.choice(boolean_options),
        'active_member': random.choice(boolean_options),
        'estimated_salary': round(random.uniform(*estimated_salary_range), 2),
        # 'churn': random.choice(boolean_options)
    }
    new_data.append(new_row)

# Convert to DataFrame
new_data_df = pd.DataFrame(new_data)


# Save to a new CSV
new_data_df.to_csv('Bank Customer Churn Prediction Extended.csv', index=False)