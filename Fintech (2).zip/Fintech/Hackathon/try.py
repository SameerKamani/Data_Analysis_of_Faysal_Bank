import streamlit as st

# Main Tab Selection
tab = st.selectbox("Select Tab", ["Tab 1", "Tab 2", "Tab 3"])

# Sub-Tab for "Tab 1"
if tab == "Tab 1":
    sub_tab = st.selectbox("Select Sub-Tab", ["Sub-tab 1A", "Sub-tab 1B"])
    if sub_tab == "Sub-tab 1A":
        st.write("Content for Sub-tab 1A")
    elif sub_tab == "Sub-tab 1B":
        st.write("Content for Sub-tab 1B")

# Sub-Tab for "Tab 2"
elif tab == "Tab 2":
    sub_tab = st.selectbox("Select Sub-Tab", ["Sub-tab 2A", "Sub-tab 2B"])
    if sub_tab == "Sub-tab 2A":
        st.write("Content for Sub-tab 2A")
    elif sub_tab == "Sub-tab 2B":
        st.write("Content for Sub-tab 2B")

# Sub-Tab for "Tab 3"
elif tab == "Tab 3":
    sub_tab = st.selectbox("Select Sub-Tab", ["Sub-tab 3A", "Sub-tab 3B"])
    if sub_tab == "Sub-tab 3A":
        st.write("Content for Sub-tab 3A")
    elif sub_tab == "Sub-tab 3B":
        st.write("Content for Sub-tab 3B")
