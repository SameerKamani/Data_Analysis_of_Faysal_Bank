# Enhanced dashboard.py with additional parameters for filter_data function

import folium
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from wordcloud import WordCloud
from datetime import datetime, timedelta
import os
import plotly.express as px
import re
import seaborn as sns
from pandasai.llm.openai import OpenAI
from pandasai.smart_dataframe import SmartDataframe
from dotenv import load_dotenv
from streamlit_folium import st_folium
from collections import defaultdict
from churn_predictor import model_pipeline

# Set Streamlit page configurations
st.set_page_config(page_title="Faysal Bank App Reviews Dashboard", layout="wide")

# Load data from CSV
def load_data():
    playstore_path = 'faisal_digibank_playstore_reviews.csv'
    appstore_path = 'faysal_digibank_appstore_reviews.csv'
    
    if os.path.exists(playstore_path) and os.path.exists(appstore_path):
        playstore_data = pd.read_csv(playstore_path)
        appstore_data = pd.read_csv(appstore_path)
        return playstore_data, appstore_data
    else:
        st.error("Review data not found. Please run the review fetching script.")
        return None, None

def load_data_meezan():
    playstore_path = 'meezan_bank_playstore_reviews.csv'
    appstore_path = 'meezan_appstore_reviews.csv'
    
    if os.path.exists(playstore_path) and os.path.exists(appstore_path):
        playstore_data = pd.read_csv(playstore_path)
        appstore_data = pd.read_csv(appstore_path)
        return playstore_data, appstore_data
    else:
        st.error("Review data not found. Please run the review fetching script.")
        return None, None
    
def load_data_soneri():
    playstore_path = 'soneri_bank_playstore_reviews.csv'
    appstore_path = 'soneri_appstore_reviews.csv'
    
    if os.path.exists(playstore_path) and os.path.exists(appstore_path):
        playstore_data = pd.read_csv(playstore_path)
        appstore_data = pd.read_csv(appstore_path)
        return playstore_data, appstore_data
    else:
        st.error("Review data not found. Please run the review fetching script.")
        return None, None

# Generate a word cloud from text data
# Generate a word cloud from text data, with column name checking
def generate_word_cloud(data):
    # Check if the expected review column exists, otherwise display an error
    if 'review' in data.columns:
        text_column = 'review'
    elif 'text' in data.columns:
        text_column = 'text'
    elif 'content' in data.columns:
        text_column = 'content'
    else:
        st.error("No suitable review text column found in data.")
        return None  # Exit the function if no review text column is found

    # Generate the word cloud if the column is found
    text = ' '.join(review for review in data[text_column].dropna())
    wordcloud = WordCloud(width=800, height=400, background_color="white").generate(text)
    fig, ax = plt.subplots()
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis('off')
    return fig

def plot_rating_distribution(data, data_meezan, data_soneri, compete):
    # Check if 'score' or 'rating' column exists
    if 'score' in data.columns:
        rating_column = 'score'
    elif 'rating' in data.columns:
        rating_column = 'rating'
    else:
        st.error("No suitable rating column found in data.")
        return

    # Count the occurrences of each rating for the main data
    rating_counts = data[rating_column].value_counts().sort_index()
    rating_counts_df = rating_counts.reset_index()
    rating_counts_df.columns = ["Rating", "Count"]

    # If compete is enabled, also count the ratings for Meezan
    if compete == "Enable":
        if 'score' in data_meezan.columns:
            rating_column_meezan = 'score'
        elif 'rating' in data_meezan.columns:
            rating_column_meezan = 'rating'
        else:
            st.error("No suitable rating column found in Meezan data.")
            return
        
        
        # Count the occurrences of each rating for Meezan
        rating_counts_meezan = data_meezan[rating_column_meezan].value_counts().sort_index()
        rating_counts_df_meezan = rating_counts_meezan.reset_index()
        rating_counts_df_meezan.columns = ["Rating", "Count_meezan"]

        if 'score' in data_soneri.columns:
            rating_column_soneri = 'score'
        elif 'rating' in data_soneri.columns:
            rating_column_soneri = 'rating'
        else:
            st.error("No suitable rating column found in soneri data.")
            return

        # Count the occurrences of each rating for Meezan
        rating_counts_soneri = data_soneri[rating_column_soneri].value_counts().sort_index()
        rating_counts_df_soneri = rating_counts_soneri.reset_index()
        rating_counts_df_soneri.columns = ["Rating", "Count_soneri"]

        # Merge the ratings data for both banks, filling missing values with 0
        rating_counts_df = pd.merge(rating_counts_df, rating_counts_df_meezan, on="Rating", how="outer").fillna(0)
        rating_counts_df = pd.merge(rating_counts_df, rating_counts_df_soneri, on="Rating", how="outer").fillna(0)
        rating_counts_df.rename(columns={"Count": "Count_faysal"}, inplace=True)
    else:
        # Rename column to Count_faysal if compete is disabled
        rating_counts_df.rename(columns={"Count": "Count_faysal"}, inplace=True)

    # Calculate percentages for each rating
    total_faysal = rating_counts_df["Count_faysal"].sum()
    rating_counts_df["Percentage_faysal"] = (rating_counts_df["Count_faysal"] / total_faysal) * 100

    if compete == "Enable":
        total_meezan = rating_counts_df["Count_meezan"].sum()
        rating_counts_df["Percentage_meezan"] = (rating_counts_df["Count_meezan"] / total_meezan) * 100

        total_soneri = rating_counts_df["Count_soneri"].sum()
        rating_counts_df["Percentage_soneri"] = (rating_counts_df["Count_soneri"] / total_soneri) * 100

    # Define color scale for gradient effect
    colors = [(0.0, "rgb(44, 39, 105)"), (0.5, "rgb(0, 128, 0)"), (1.0, "rgb(0, 128, 128)")]  # Dark blue to teal gradient

    # If competing data is not enabled, create a simple bar chart for Faysal Bank
    if compete != "Enable":
        fig = px.bar(
            rating_counts_df,
            x="Rating",
            y="Count_faysal",
            text="Count_faysal",  # Adds the count text on top of bars
            color="Rating",
            color_continuous_scale=colors
        )

        # Customize layout
        fig.update_traces(texttemplate='%{text}', textposition='outside')
        fig.update_layout(
            title="Rating Distribution",
            xaxis_title="Ratings",
            yaxis_title="Count of Ratings",
            coloraxis_showscale=False  # Hide color scale if not needed
        )

        # Display the plot in Streamlit
        st.plotly_chart(fig)

    # If competing data is enabled, create a grouped bar chart
    else:
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            x=rating_counts_df["Rating"],
            y=rating_counts_df["Percentage_faysal"],
            name="Faysal Bank",
            marker_color="rgba(0, 128, 128, 1)",  # Teal color
            text=[f"{count} ({pct:.1f}%)" for count, pct in zip(rating_counts_df["Count_faysal"], rating_counts_df["Percentage_faysal"])],
            textposition="outside",
            hoverinfo="y",
            offsetgroup=1
        ))

        fig.add_trace(go.Bar(
            x=rating_counts_df["Rating"],
            y=rating_counts_df["Percentage_meezan"],
            name="Meezan",
            marker_color="Purple",  # Pink color
            text=[f"{count} ({pct:.1f}%)" for count, pct in zip(rating_counts_df["Count_meezan"], rating_counts_df["Percentage_meezan"])],
            textposition="outside",
            hoverinfo="y",
            offsetgroup=2
        ))

        fig.add_trace(go.Bar(
            x=rating_counts_df["Rating"],
            y=rating_counts_df["Percentage_soneri"],
            name="Soneri",
            marker_color="Orange",  # Pink color
            text=[f"{count} ({pct:.1f}%)" for count, pct in zip(rating_counts_df["Count_soneri"], rating_counts_df["Percentage_soneri"])],
            textposition="outside",
            hoverinfo="y",
            offsetgroup=3
        ))

        # Customize layout
        fig.update_layout(
            title="Rating Distribution",
            xaxis_title="Ratings",
            yaxis_title="Percentage of Ratings",
            barmode="group",
            xaxis=dict(
                title="Rating",
                title_font=dict(size=20),
                tickfont=dict(size=18)
            ),
            yaxis=dict(
                title="Percentage of Ratings",
                title_font=dict(size=20),
                tickfont=dict(size=18)
            ),
            legend=dict(
                orientation="h",
                yanchor="top",
                y=1.1,
                xanchor="center",
                x=0.5,
                font=dict(size=18)
            ),
        )

        # Display the plot in Streamlit
        st.plotly_chart(fig)


def display_ratings_timeline(data, view, data_meezan, data_soneri, compete):
    # Check for the presence of a column that holds rating data
    if 'score' in data.columns:
        rating_column = 'score'
    elif 'rating' in data.columns:
        rating_column = 'rating'
    else:
        st.error("No suitable rating column found in data.")
        return  # Exit function if no rating column is found

    # Check for date column
    if 'date' not in data.columns:
        st.error("No date column found in data.")
        return  # Exit if no date column is found

    # Convert the date column to datetime format if not already in datetime
    data['date'] = pd.to_datetime(data['date'], errors='coerce')

    # Group data based on the selected view (monthly or yearly)
    if view == 'Monthly':
        data['period'] = data['date'].dt.to_period('M')  # Group by month
    else:
        data['period'] = data['date'].dt.to_period('Y')  # Group by year

    ratings_timeline = data.groupby('period')[rating_column].mean().reset_index()

    # Convert period back to timestamp for plotting
    ratings_timeline['period'] = ratings_timeline['period'].dt.to_timestamp()

    # Create a color gradient inspired by purple -> teal -> white
    def get_color(rating):
        # Define the RGB colors for purple, teal, and white
        purple = (44, 39, 105)  # Purple color
        teal = (0, 128, 128)    # Teal color
        green_ = (0, 128, 0) # White color

        # Scale the rating to the range [0, 1]
        scale = min(max((rating - 1) / 4, 0), 1)  # Scale rating to 0-1 range
        
        # Interpolate between the three colors based on the rating
        if scale <= 0.5:  # From purple to teal
            red = int(purple[0] + scale * (green_[0] - purple[0]))
            green = int(purple[1] + scale * (green_[1] - purple[1]))
            blue = int(purple[2] + scale * (green_[2] - purple[2]))
        else:  # From teal to white
            scale = (scale - 0.5) * 2  # Adjust scale for interpolation with white
            red = int(green_[0] + scale * (teal[0] - green_[0]))
            green = int(green_[1] + scale * (teal[1] - green_[1]))
            blue = int(green_[2] + scale * (teal[2] - green_[2]))

        return f'rgba({red}, {green}, {blue}, 1)'

    # Create figure
    fig = go.Figure()

    # Add traces for the main ratings data
    for i in range(len(ratings_timeline) - 1):
        x_values = ratings_timeline['period'].iloc[i:i + 2]
        y_values = ratings_timeline[rating_column].iloc[i:i + 2]
        color = get_color(y_values.mean())  # Get color based on the average rating

        if compete != "Enable":
            fig.add_trace(go.Scatter(
                x=x_values,
                y=y_values,
                mode='lines+markers',
                marker=dict(color=color),
                line=dict(color=color),
                showlegend=False
            ))
        else:
            fig.add_trace(go.Scatter(
                x=x_values,
                y=y_values,
                mode='lines+markers',
                marker=dict(color="teal"),
                line=dict(color="teal"),
                showlegend=False
            ))

    if compete != "Enable":
        # Add a legend for the color key
        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='rgba(44, 39, 105, 1)', size=10),
            name='Low Rating'  # Label for purple color
        ))
        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='rgba(0, 128, 0, 1)', size=10),
            name='Medium Rating'  # Label for green color
        ))
        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='rgba(0, 128, 128, 1)', size=10),
            name='High Rating'  # Label for teal color
        ))

    # If compete is enabled, include the data_meezan in the plot
    if compete == "Enable":
        if 'score' in data_meezan.columns:
            rating_column_meezan = 'score'
        elif 'rating' in data_meezan.columns:
            rating_column_meezan = 'rating'
        else:
            st.error("No suitable rating column found in data_meezan.")
            return  # Exit function if no rating column is found in data_meezan

        # Check for date column in data_meezan
        if 'date' not in data_meezan.columns:
            st.error("No date column found in data_meezan.")
            return  # Exit if no date column is found in data_meezan

        # Convert the date column in data_meezan to datetime format if not already in datetime
        data_meezan['date'] = pd.to_datetime(data_meezan['date'], errors='coerce')

        # Group data_meezan based on the selected view (monthly or yearly)
        if view == 'Monthly':
            data_meezan['period'] = data_meezan['date'].dt.to_period('M')  # Group by month
        else:
            data_meezan['period'] = data_meezan['date'].dt.to_period('Y')  # Group by year

        ratings_timeline_meezan = data_meezan.groupby('period')[rating_column_meezan].mean().reset_index()

        # Convert period back to timestamp for plotting
        ratings_timeline_meezan['period'] = ratings_timeline_meezan['period'].dt.to_timestamp()

        # Add traces for the meezan ratings data
        for i in range(len(ratings_timeline_meezan) - 1):
            x_values = ratings_timeline_meezan['period'].iloc[i:i + 2]
            y_values = ratings_timeline_meezan[rating_column_meezan].iloc[i:i + 2]
            #color = get_color_meezan(y_values.mean())  # Get color based on the average rating

            fig.add_trace(go.Scatter(
                x=x_values,
                y=y_values,
                mode='lines+markers',
                marker=dict(color="purple"),
                line=dict(color="purple"),
                showlegend=False
            ))
        
        if 'score' in data_soneri.columns:
            rating_column_soneri = 'score'
        elif 'rating' in data_soneri.columns:
            rating_column_soneri = 'rating'
        else:
            st.error("No suitable rating column found in data_soneri.")
            return  # Exit function if no rating column is found in data_soneri

        # Check for date column in data_soneri
        if 'date' not in data_soneri.columns:
            st.error("No date column found in data_soneri.")
            return  # Exit if no date column is found in data_soneri

        # Convert the date column in data_soneri to datetime format if not already in datetime
        data_soneri['date'] = pd.to_datetime(data_soneri['date'], errors='coerce')

        # Group data_soneri based on the selected view (monthly or yearly)
        if view == 'Monthly':
            data_soneri['period'] = data_soneri['date'].dt.to_period('M')  # Group by month
        else:
            data_soneri['period'] = data_soneri['date'].dt.to_period('Y')  # Group by year

        ratings_timeline_soneri = data_soneri.groupby('period')[rating_column_soneri].mean().reset_index()

        # Convert period back to timestamp for plotting
        ratings_timeline_soneri['period'] = ratings_timeline_soneri['period'].dt.to_timestamp()

        # Add traces for the soneri ratings data
        for i in range(len(ratings_timeline_soneri) - 1):
            x_values = ratings_timeline_soneri['period'].iloc[i:i + 2]
            y_values = ratings_timeline_soneri[rating_column_soneri].iloc[i:i + 2]
            #color = get_color_soneri(y_values.mean())  # Get color based on the average rating

            fig.add_trace(go.Scatter(
                x=x_values,
                y=y_values,
                mode='lines+markers',
                marker=dict(color="orange"),
                line=dict(color="orange"),
                showlegend=False
            ))

        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='rgba(44, 39, 105, 1)', size=10),
            name='Faysal Bank'  # Label for purple color
        ))

        # Add a legend for the meezan data
        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='purple', size=10),
            name='Meezan Bank'  # Label for purple color
        ))

        # Add a legend for the Soneri data
        fig.add_trace(go.Scatter(
            x=[None], y=[None],  # No data points, just a placeholder
            mode='markers',
            marker=dict(color='orange', size=10),
            name='Soneri Bank'  # Label for purple color
        ))

    # Customize layout
    fig.update_layout(
        title=f'Average Rating Over {view}s',
        xaxis_title=f'{view}',
        yaxis_title='Average Rating',
        xaxis=dict(showgrid=True),
        yaxis=dict(showgrid=True),
        showlegend=True  # Enable legend
    )

    # Display the plot in Streamlit
    st.plotly_chart(fig)

def perform_sentiment_analysis(compete):
    # Load sentiment data
    playstore_sentiment_path = 'playstore_sentiment_counts.csv'
    appstore_sentiment_path = 'appstore_sentiment_counts.csv'
    playstore_sentiment_path_meezan = 'playstore_sentiment_counts_meezan.csv'  # Path for Meezan sentiment data
    appstore_sentiment_path_meezan = 'appstore_sentiment_counts_meezan.csv'
    playstore_sentiment_path_soneri = 'playstore_sentiment_counts_soneri.csv'  # Path for soneri sentiment data
    appstore_sentiment_path_soneri = 'appstore_sentiment_counts_soneri.csv'

    if os.path.exists(playstore_sentiment_path) and os.path.exists(appstore_sentiment_path):
        # Read Playstore and Appstore sentiment data
        playstore_sentiment_data = pd.read_csv(playstore_sentiment_path)
        appstore_sentiment_data = pd.read_csv(appstore_sentiment_path)

        # Merge sentiment data by adding respective values together
        sentiment_data = playstore_sentiment_data.set_index('Aspect').add(appstore_sentiment_data.set_index('Aspect'), fill_value=0).reset_index()

        # Adjust sentiment counts by adding half of the neutral count to negative
        sentiment_data['Positive'] += sentiment_data['Neutral'] / 2
        sentiment_data['Negative'] += sentiment_data['Neutral'] / 2
        sentiment_data = sentiment_data.drop(columns=['Neutral'])

        # Round sentiment counts
        sentiment_data[['Positive', 'Negative']] = sentiment_data[['Positive', 'Negative']].round()

        # Calculate additional columns
        sentiment_data['Ratio'] = (sentiment_data['Positive'] / sentiment_data['Negative']).replace([float('inf'), -float('inf')], 0).fillna(0)
        sentiment_data['Difference'] = sentiment_data['Positive'] - sentiment_data['Negative']
        sentiment_data['Total'] = sentiment_data['Positive'] + sentiment_data['Negative']

        # Calculate percentage of positive and negative reviews for the chart
        sentiment_data['Positive Percentage'] = (sentiment_data['Positive'] / sentiment_data['Total']) * 100
        sentiment_data['Negative Percentage'] = (sentiment_data['Negative'] / sentiment_data['Total']) * 100

        # Create a Plotly figure for the sentiment chart
        fig = go.Figure()

        # Define colors based on the sentiment (positive and negative)
        positive_color = "rgba(0, 128, 128, 1)"  # Teal color for Positive
        negative_color = "rgba(44, 39, 105, 1)"  # Dark blue color for Negative

        # Add Positive sentiment bars for Playstore + Appstore (grouped side by side)
        # Add Positive sentiment bars for Faysal (Playstore + Appstore)
        fig.add_trace(go.Bar(
            x=sentiment_data["Aspect"],
            y=sentiment_data["Positive Percentage"],
            name="Faysal Positive",
            marker_color=positive_color,
            text=[f"{pos_count} ({pos_pct:.1f}%)" for pos_count, pos_pct in zip(sentiment_data["Positive"], sentiment_data["Positive Percentage"])],
            textposition="outside",
            texttemplate='%{text}',
            textfont=dict(size=16, color="black"),  # Set text color to black
            hoverinfo="y",
            offsetgroup=1
        ))

        # Add Negative sentiment bars for Faysal (Playstore + Appstore)
        fig.add_trace(go.Bar(
            x=sentiment_data["Aspect"],
            y=-sentiment_data["Negative Percentage"],
            name="Faysal Negative",
            marker_color=negative_color,
            text=[f"{neg_count} ({neg_pct:.1f}%)" for neg_count, neg_pct in zip(sentiment_data["Negative"], sentiment_data["Negative Percentage"])],
            textposition="outside",
            texttemplate='%{text}',
            textfont=dict(size=16, color="black"),  # Set text color to black
            hoverinfo="y",
            offsetgroup=1
        ))


        # Display the sentiment data table
        if compete != "Enable":
            st.header("Sentiment Analysis Table")
            st.dataframe(sentiment_data)

        # If compete is enabled, include the Meezan sentiment analysis
        if compete == "Enable":
            # Load Meezan sentiment data
            if os.path.exists(playstore_sentiment_path_meezan) and os.path.exists(appstore_sentiment_path_meezan):
                playstore_sentiment_data = pd.read_csv(playstore_sentiment_path_meezan)
                appstore_sentiment_data = pd.read_csv(appstore_sentiment_path_meezan)

                # Merge the Meezan sentiment data
                meezan_sentiment_data = playstore_sentiment_data.set_index('Aspect').add(appstore_sentiment_data.set_index('Aspect'), fill_value=0).reset_index()

                # Adjust Meezan sentiment counts by adding half of the neutral count to negative
                meezan_sentiment_data['Positive'] += meezan_sentiment_data['Neutral'] / 2
                meezan_sentiment_data['Negative'] += meezan_sentiment_data['Neutral'] / 2
                meezan_sentiment_data = meezan_sentiment_data.drop(columns=['Neutral'])

                # Round sentiment counts for Meezan
                meezan_sentiment_data[['Positive', 'Negative']] = meezan_sentiment_data[['Positive', 'Negative']].round()

                meezan_sentiment_data['Ratio'] = (meezan_sentiment_data['Positive'] / meezan_sentiment_data['Negative']).replace([float('inf'), -float('inf')], 0).fillna(0)
                meezan_sentiment_data['Difference'] = meezan_sentiment_data['Positive'] - meezan_sentiment_data['Negative']
                meezan_sentiment_data['Total'] = meezan_sentiment_data['Positive'] + meezan_sentiment_data['Negative']

                # Calculate additional columns for Meezan
                meezan_sentiment_data['Total'] = meezan_sentiment_data['Positive'] + meezan_sentiment_data['Negative']
                meezan_sentiment_data['Positive Percentage'] = (meezan_sentiment_data['Positive'] / meezan_sentiment_data['Total']) * 100
                meezan_sentiment_data['Negative Percentage'] = (meezan_sentiment_data['Negative'] / meezan_sentiment_data['Total']) * 100

                # Add Positive sentiment bars for Meezan
                fig.add_trace(go.Bar(
                    x=meezan_sentiment_data["Aspect"],
                    y=meezan_sentiment_data["Positive Percentage"],
                    name="Meezan Positive",
                    marker_color="Green",
                    text=[f"{pos_count} ({pos_pct:.1f}%)" for pos_count, pos_pct in zip(meezan_sentiment_data["Positive"], meezan_sentiment_data["Positive Percentage"])],
                    textposition="outside",
                    texttemplate='%{text}',
                    textfont=dict(size=16, color="black"),  # Set text color to black
                    hoverinfo="y",
                    offsetgroup=2
                ))

                # Add Negative sentiment bars for Meezan
                fig.add_trace(go.Bar(
                    x=meezan_sentiment_data["Aspect"],
                    y=-meezan_sentiment_data["Negative Percentage"],
                    name="Meezan Negative",
                    marker_color="Purple",
                    text=[f"{neg_count} ({neg_pct:.1f}%)" for neg_count, neg_pct in zip(meezan_sentiment_data["Negative"], meezan_sentiment_data["Negative Percentage"])],
                    textposition="outside",
                    texttemplate='%{text}',
                    textfont=dict(size=16, color="black"),  # Set text color to black
                    hoverinfo="y",
                    offsetgroup=2
                ))

                playstore_sentiment_data = pd.read_csv(playstore_sentiment_path_soneri)
                appstore_sentiment_data = pd.read_csv(appstore_sentiment_path_soneri)

                # Merge the soneri sentiment data
                soneri_sentiment_data = playstore_sentiment_data.set_index('Aspect').add(appstore_sentiment_data.set_index('Aspect'), fill_value=0).reset_index()

                # Adjust soneri sentiment counts by adding half of the neutral count to negative
                soneri_sentiment_data['Positive'] += soneri_sentiment_data['Neutral'] / 2
                soneri_sentiment_data['Negative'] += soneri_sentiment_data['Neutral'] / 2
                soneri_sentiment_data = soneri_sentiment_data.drop(columns=['Neutral'])

                # Round sentiment counts for soneri
                soneri_sentiment_data[['Positive', 'Negative']] = soneri_sentiment_data[['Positive', 'Negative']].round()

                soneri_sentiment_data['Ratio'] = (soneri_sentiment_data['Positive'] / soneri_sentiment_data['Negative']).replace([float('inf'), -float('inf')], 0).fillna(0)
                soneri_sentiment_data['Difference'] = soneri_sentiment_data['Positive'] - soneri_sentiment_data['Negative']
                soneri_sentiment_data['Total'] = soneri_sentiment_data['Positive'] + soneri_sentiment_data['Negative']

                # Calculate additional columns for soneri
                soneri_sentiment_data['Total'] = soneri_sentiment_data['Positive'] + soneri_sentiment_data['Negative']
                soneri_sentiment_data['Positive Percentage'] = (soneri_sentiment_data['Positive'] / soneri_sentiment_data['Total']) * 100
                soneri_sentiment_data['Negative Percentage'] = (soneri_sentiment_data['Negative'] / soneri_sentiment_data['Total']) * 100

                # Add Positive sentiment bars for soneri
                fig.add_trace(go.Bar(
                    x=soneri_sentiment_data["Aspect"],
                    y=soneri_sentiment_data["Positive Percentage"],
                    name="Soneri Positive",
                    marker_color="orange",
                    text=[f"{pos_count} ({pos_pct:.1f}%)" for pos_count, pos_pct in zip(soneri_sentiment_data["Positive"], soneri_sentiment_data["Positive Percentage"])],
                    textposition="outside",
                    texttemplate='%{text}',
                    textfont=dict(size=16, color="black"),  # Set text color to black
                    hoverinfo="y",
                    offsetgroup=3
                ))

                # Add Negative sentiment bars for soneri
                fig.add_trace(go.Bar(
                    x=soneri_sentiment_data["Aspect"],
                    y=-soneri_sentiment_data["Negative Percentage"],
                    name="Soneri Negative",
                    marker_color="black",
                    text=[f"{neg_count} ({neg_pct:.1f}%)" for neg_count, neg_pct in zip(soneri_sentiment_data["Negative"], soneri_sentiment_data["Negative Percentage"])],
                    textposition="outside",
                    texttemplate='%{text}',
                    textfont=dict(size=16, color="black"),  # Set text color to black
                    hoverinfo="y",
                    offsetgroup=3
                ))

            st.header("Faysal Bank Sentiment Analysis Table")
            st.dataframe(sentiment_data)
            st.header("Meezan Bank Sentiment Analysis Table")
            st.dataframe(meezan_sentiment_data)
            st.header("Soneri Bank Sentiment Analysis Table")
            st.dataframe(soneri_sentiment_data)

        # Customize layout for the diverging bar chart (positive and negative side by side)
        fig.update_layout(
            title=dict(
                text="Sentiment Analysis Graph",
                font=dict(size=30, color="black")  # Set title font color to black
            ),
            barmode="group",
            xaxis=dict(
                title="Aspect",
                title_font=dict(size=26, color="black"),  # Set x-axis title color to black
                tickfont=dict(size=22, color="black")     # Set x-axis tick color to black
            ),
            yaxis=dict(
                title="Sentiment Percentage",
                tickvals=[-100, -75, -50, -25, 0, 25, 50, 75, 100],
                ticktext=[ 
                    '<span style="color:rgb(44, 39, 105)">-100%</span>',
                    '<span style="color:rgb(44, 39, 105)">-75%</span>',
                    '<span style="color:rgb(44, 39, 105)">-50%</span>',
                    '<span style="color:rgb(44, 39, 105)">-25%</span>',
                    '0%',
                    '<span style="color:teal">25%</span>',
                    '<span style="color:teal">50%</span>',
                    '<span style="color:teal">75%</span>',
                    '<span style="color:teal">100%</span>'
                ],
                title_font=dict(size=26, color="black"),  # Set y-axis title color to black
                tickfont=dict(size=22),  # Keep tick font color as per custom ticktext above
                showgrid=True,
                gridcolor='gray',
                gridwidth=0.5
            ),
            legend=dict(
                orientation="h",
                yanchor="top",
                y=1.1,
                xanchor="center",
                x=0.5,
                font=dict(size=22, color="black")  # Set legend font color to black
            )
        )


        # Add a line at y=0 (neutral line)
        fig.add_shape(
            go.layout.Shape(
                type="line",
                x0=-0.5,
                x1=len(sentiment_data["Aspect"]) - 0.5,
                y0=0,
                y1=0,
                line=dict(color="black", width=2, dash="dash")
            )
        )

        # Display the Plotly figure in Streamlit
        st.plotly_chart(fig)

    else:
        st.error("Sentiment data not found. Please ensure the sentiment CSV files are available.")

def map_analysis():
    # Load the branch and review data
    branches_data = pd.read_csv("info.csv")
    reviews_data = pd.read_csv("r.csv")
    meezan_branches = pd.read_csv("m_info.csv")
    meezan_reviews = pd.read_csv("m_r.csv")
    soneri_branches = pd.read_csv("s_info.csv")
    soneri_reviews = pd.read_csv("s_r.csv")

    with st.sidebar:
        customer_review = st.radio("Bank Customer Reviews", ("Faysal Bank", "Meezan Bank", "Soneri Bank"))

    # Initialize the Streamlit page
    st.title("Bank Branches Map")
    # st.sidebar.header("Branch Selection")
    city = st.selectbox("Select a City", branches_data['City'].unique())
    # Create a new column combining Branch Name and BranchID
    branches_data['Branch Name + ID'] = branches_data['Name'] + ' (' + branches_data['BranchID'].astype(str) + ')'
    meezan_branches['Branch Name + ID'] = meezan_branches['Name'] + ' (' + meezan_branches['BranchID'].astype(str) + ')'
    soneri_branches['Branch Name + ID'] = soneri_branches['Name'] + ' (' + soneri_branches['BranchID'].astype(str) + ')'

    # Folium Map Initialization
    islamabad_coords = [33.6844, 73.0479]  # Center point for Islamabad
    karachi_coords = [24.8607, 67.0011]  # Center point for Karachi
    quetta_coords = [30.1798, 66.9750]  # Center point for Quetta

    if city == 'Islamabad':
        coords = islamabad_coords
    elif city == 'Karachi':
        coords = karachi_coords
    elif city == 'Quetta':
        coords = quetta_coords

    # Sidebar - Branch selection with Branch Name + Branch ID
    # branch_name_id = st.sidebar.selectbox("Select a Branch", soneri_branches['Branch Name + ID'])
    # st.write(f"### Selected Branch: {branch_name_id}")
    branch_info = branches_data[branches_data['Branch Name + ID'] == "Faysal Bank (1)" ].iloc[0]
    meezan_branch_info = meezan_branches[meezan_branches['Branch Name + ID'] == "Meezan Bank - Block-18 Gulistan-e-Jauhar Branch (100)" ].iloc[0]
    soneri_branch_info = soneri_branches[soneri_branches['Branch Name + ID'] == "Soneri Bank, Suparco Branch (200)" ].iloc[0]

    st.subheader("Interactive Map of Bank Branches")

    def create_aspect_sentiment_dict(reviews_data):
        sentiment_dict = defaultdict(lambda: {'positive': 0, 'negative': 0, 'neutral': 0})
        
        for _, row in reviews_data.iterrows():
            aspect = row['aspect']
            sentiment = row['sentiment']
            
            if sentiment in sentiment_dict[aspect]:
                sentiment_dict[aspect][sentiment] += 1
        
        return dict(sentiment_dict)

    def update_map(branches_data, selected_branch, selected_meezan, selected_soneri):
        m = folium.Map(location=coords, zoom_start=12)         
            
        for _, row in meezan_branches.iterrows():
            if row['BranchID'] == selected_meezan['BranchID']:
                marker_color = 'red'
            else:
                marker_color = 'purple'
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                popup=f"{row['Name']} - {row['Address']}\nCity: {row['City']}\nRating: {row['Ratings']}/5\nReviews: {row['num rev']}",
                tooltip=row['Name'],
                icon=folium.Icon(color=marker_color)
            ).add_to(m)

        for _, row in soneri_branches.iterrows():
            if row['BranchID'] == selected_soneri['BranchID']:
                marker_color = 'cadetblue'
            else:
                marker_color = 'orange'
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                popup=f"{row['Name']} - {row['Address']}\nCity: {row['City']}\nRating: {row['Ratings']}/5\nReviews: {row['num rev']}",
                tooltip=row['Name'],
                icon=folium.Icon(color=marker_color)
            ).add_to(m)

        for _, row in branches_data.iterrows():
            branch_id = row['BranchID']
            filename = f"reviews/reviews_{branch_id}.csv"

            if row['BranchID'] == selected_branch['BranchID']:
                marker_color = 'green'  # Color for selected branch
            else:
                try:
                    sentiments = pd.read_csv(filename)
                    positive_count = sentiments[sentiments['sentiment'] == 'positive'].shape[0]
                    negative_count = sentiments[sentiments['sentiment'] == 'negative'].shape[0]
                    
                    if positive_count > negative_count:
                        marker_color = 'blue'
                    elif negative_count > positive_count:
                        marker_color = 'blue'
                    else:
                        marker_color = 'blue'  # Neutral or no reviews
                    
                except FileNotFoundError:
                    marker_color = 'black'  # Default color if no review file is found
            
                # folium.Marker(
                #     location=[row['latitude'], row['longitude']],
                #     popup=f"{row['Name']} - {row['Address']}\nCity: {row['City']}\nRating: {row['Ratings']}/5\nReviews: {row['num rev']}",
                #     tooltip=row['Name'],
                #     icon=folium.Icon(color=marker_color)
                # ).add_to(m)
            
            folium.Marker(
                location=[row['latitude'], row['longitude']],
                popup=f"{row['Name']} - {row['Address']}\nCity: {row['City']}\nRating: {row['Ratings']}/5\nReviews: {row['num rev']}",
                tooltip=row['Name'],
                icon=folium.Icon(color=marker_color)
            ).add_to(m)

        map_data = st_folium(m, width=700, height=500)

        with st.sidebar:

            if customer_review == "Faysal Bank":
                selected_branch_reviews = reviews_data[(reviews_data['BranchID'] == selected_branch['BranchID']) & (reviews_data['Name'] == selected_branch['Name'])]

                st.write("### Selected Faysal Bank Branch Information")
                st.write(f"*Branch Name:* {selected_branch['Name']}")
                st.write(f"*Address:* {selected_branch['Address']}")
                st.write(f"*City:* {selected_branch['City']}")
                st.write(f"*Ratings:* {selected_branch['Ratings']}/5")
                st.write(f"*Number of Reviews:* {selected_branch['num rev']}")

                st.write("### Customer Reviews")

                if not selected_branch_reviews.empty:
                    for _, review in selected_branch_reviews.iterrows():
                        st.write(f"**{review['Name']}**")
                        st.write(review['Reviews'])
                        st.write("---")  # Separator line
                else:
                    st.write("No reviews available for this branch.")

            if customer_review == "Meezan Bank":
                selected_meezan_reviews = meezan_reviews[(meezan_reviews['BranchID'] == selected_meezan['BranchID']) & (meezan_reviews['Name'] == selected_meezan['Name'])]

                st.write("### Selected Meezan Bank Branch Information")
                st.write(f"*Branch Name:* {selected_meezan['Name']}")
                st.write(f"*Address:* {selected_meezan['Address']}")
                st.write(f"*City:* {selected_meezan['City']}")
                st.write(f"*Ratings:* {selected_meezan['Ratings']}/5")
                st.write(f"*Number of Reviews:* {selected_meezan['num rev']}")

                st.write("### Customer Reviews")

                if not selected_meezan_reviews.empty:
                    for _, review in selected_meezan_reviews.iterrows():
                        st.write(f"**{review['Name']}**")
                        st.write(review['Reviews'])
                        st.write("---")  # Separator line
                else:
                    st.write("No reviews available for this branch.")

            if customer_review == "Soneri Bank":
                selected_soneri_reviews = soneri_reviews[(soneri_reviews['BranchID'] == selected_soneri['BranchID']) & (soneri_reviews['Name'] == selected_soneri['Name'])]

                st.write("### Selected Soneri Bank Branch Information")
                st.write(f"*Branch Name:* {selected_soneri['Name']}")
                st.write(f"*Address:* {selected_soneri['Address']}")
                st.write(f"*City:* {selected_soneri['City']}")
                st.write(f"*Ratings:* {selected_soneri['Ratings']}/5")
                st.write(f"*Number of Reviews:* {selected_soneri['num rev']}")

                st.write("### Customer Reviews")

                if not selected_soneri_reviews.empty:
                    for _, review in selected_soneri_reviews.iterrows():
                        st.write(f"**{review['Name']}**")
                        st.write(review['Reviews'])
                        st.write("---")  # Separator line

        
        st.write("### Sentiment Analysis")
        branch_id = selected_branch['BranchID']
        meezan_branchID = selected_meezan['BranchID']
        soneri_branchID = selected_soneri['BranchID']
        filename = f"reviews/reviews_{branch_id}.csv"
        meezan_filename = f"m_reviews/reviews_{meezan_branchID}.csv"
        soneri_filename = f"s_reviews/reviews_{soneri_branchID}.csv"

        # Read sentiment data
        sentiments = pd.read_csv(filename)
        meezan_sentiments = pd.read_csv(meezan_filename)
        soneri_sentiments = pd.read_csv(soneri_filename)

        # Process sentiment data
        aspect_sentiment_dict = create_aspect_sentiment_dict(sentiments)
        meezan_aspect_sentiment_dict = create_aspect_sentiment_dict(meezan_sentiments)
        soneri_aspect_sentiment_dict = create_aspect_sentiment_dict(soneri_sentiments)

        # Prepare aspects and sentiment counts
        aspects = list(set(aspect_sentiment_dict.keys()) | set(meezan_aspect_sentiment_dict.keys()) | set(soneri_aspect_sentiment_dict.keys()))

        # Faysal Bank sentiment counts
        positive_counts = [aspect_sentiment_dict.get(aspect, {'positive': 0})['positive'] for aspect in aspects]
        negative_counts = [aspect_sentiment_dict.get(aspect, {'negative': 0})['negative'] for aspect in aspects]

        # Meezan Bank sentiment counts
        meezan_positive_counts = [meezan_aspect_sentiment_dict.get(aspect, {'positive': 0})['positive'] for aspect in aspects]
        meezan_negative_counts = [meezan_aspect_sentiment_dict.get(aspect, {'negative': 0})['negative'] for aspect in aspects]

        # Soneri Bank sentiment counts
        soneri_positive_counts = [soneri_aspect_sentiment_dict.get(aspect, {'positive': 0})['positive'] for aspect in aspects]
        soneri_negative_counts = [soneri_aspect_sentiment_dict.get(aspect, {'negative': 0})['negative'] for aspect in aspects]

        # Create a Plotly bar chart
        fig = go.Figure()

        # Add bars for Faysal Bank
        fig.add_trace(go.Bar(
            x=aspects,
            y=positive_counts,
            name='Faysal Positive',
            marker_color='white'
        ))
        fig.add_trace(go.Bar(
            x=aspects,
            y=negative_counts,
            name='Faysal Negative',
            marker_color='teal'
        ))

        # Add bars for Meezan Bank
        fig.add_trace(go.Bar(
            x=aspects,
            y=meezan_positive_counts,
            name='Meezan Positive',
            marker_color='purple'
        ))
        fig.add_trace(go.Bar(
            x=aspects,
            y=meezan_negative_counts,
            name='Meezan Negative',
            marker_color='green'
        ))

        # Add bars for Soneri Bank
        fig.add_trace(go.Bar(
            x=aspects,
            y=soneri_positive_counts,
            name='Soneri Positive',
            marker_color='yellow'
        ))
        fig.add_trace(go.Bar(
            x=aspects,
            y=soneri_negative_counts,
            name='Soneri Negative',
            marker_color='blue'
        ))

        # Update layout for better readability
        fig.update_layout(
            barmode='group',  # Group bars by aspect
            title='Sentiment Analysis by Aspect',
            xaxis_title='Aspects',
            yaxis_title='Counts',
            xaxis_tickangle=-45,
            template='plotly_dark',  # Dark theme for the plot
            legend_title='Banks'
        )

        # Display the plot in Streamlit
        st.plotly_chart(fig)

        # Plot sentiment analysis results
        # aspects = list(aspect_sentiment_dict.keys())
        # positive_counts = [aspect_sentiment_dict[aspect]['positive'] for aspect in aspects]
        # negative_counts = [aspect_sentiment_dict[aspect]['negative'] for aspect in aspects]
        # # neutral_counts = [aspect_sentiment_dict[aspect]['neutral'] for aspect in aspects]

        # fig, ax = plt.subplots(figsize=(10, 6))

        # # Set the background color to black
        # fig.patch.set_facecolor('black')
        # ax.set_facecolor('black')

        # bar_width = 0.25
        # index = range(len(aspects))

        # bar1 = ax.bar(index, positive_counts, bar_width, label='Positive', color='g')
        # bar2 = ax.bar([i + bar_width for i in index], negative_counts, bar_width, label='Negative', color='r')
        # # bar3 = ax.bar([i + 2 * bar_width for i in index], neutral_counts, bar_width, label='Neutral', color='b')

        # ax.set_xlabel('Aspects', color='white')
        # ax.set_ylabel('Counts', color='white')
        # ax.set_title('Sentiment Analysis by Aspect', color='white')
        # ax.set_xticks([i + bar_width for i in index])
        # ax.set_xticklabels(aspects, rotation=45, color='white')
        # ax.legend()

        # # Change the color of the tick labels
        # ax.tick_params(axis='x', colors='white')
        # ax.tick_params(axis='y', colors='white')

        # st.pyplot(fig)
        
        return map_data

    if 'selected' not in st.session_state:
        map_data = update_map(branches_data, branch_info, meezan_branch_info, soneri_branch_info)
    else:
        map_data = update_map(branches_data, st.session_state.selected, st.session_state.selected_meezan, st.session_state.selected_soneri)


    if map_data and map_data.get("last_clicked"):
        lat, lon = map_data["last_clicked"]["lat"], map_data["last_clicked"]["lng"]
        
        # Find the closest branch to the clicked point
        selected_branch = branches_data.loc[
            ((branches_data['latitude'] - lat)**2 + (branches_data['longitude'] - lon)**2).idxmin()
        ]
        # Find the closest Meezan Bank branch to the selected branch
        meezan_branches['distance'] = ((meezan_branches['latitude'] - lat)**2 + (meezan_branches['longitude'] - lon)**2)
        closest_meezan_branch = meezan_branches.loc[meezan_branches['distance'].idxmin()]

        # Find the closest Soneri Bank branch to the selected branch
        soneri_branches['distance'] = ((soneri_branches['latitude'] - lat)**2 + (soneri_branches['longitude'] - lon)**2)
        closest_soneri_branch = soneri_branches.loc[soneri_branches['distance'].idxmin()]

        st.session_state.selected = selected_branch
        st.session_state.selected_meezan = closest_meezan_branch
        st.session_state.selected_soneri = closest_soneri_branch
        st.rerun()

def chatbot():
    # Load environment variables from secret.env file
    load_dotenv('secret.env')
    openai_api_key = os.getenv('OPENAI_API_KEY')

    # Function to clean data in the CSV
    def clean_data(df):
        if 'rating' in df.columns:
            df = df.dropna(subset=['rating'])
        elif 'score' in df.columns:
            df = df.dropna(subset=['score'])
        else:
            st.warning("No 'rating' column found. Please ensure your CSV includes a 'rating' column.")
            return df

        for col in df.columns:
            if pd.api.types.is_string_dtype(df[col]):
                df[col] = df[col].fillna('').apply(preprocess_text)
            elif pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].fillna(0)
        return df

    # Text preprocessing function
    def preprocess_text(text):
        text = text.lower()
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
        return text

    # Function to enhance prompt for concise and focused responses
    def enhance_prompt(prompt):
        if "top" in prompt.lower() and "issues" in prompt.lower():
            return f"Identify the top issues from the data based on frequency or severity. Provide a summary with key points."
        elif "trend" in prompt.lower():
            return f"Identify any trends or patterns in the data over time. Provide insights into any shifts in ratings or sentiments."
        elif "sentiment" in prompt.lower():
            return f"Analyze the sentiment distribution in the reviews. Identify the overall sentiment and any notable shifts."
        return prompt

    # Function to parse a time range from the user's query
    def parse_time_range(query):
        time_range = None
        match = re.search(r'(\d+)\s*(month|week|day)', query.lower())
        if match:
            num = int(match.group(1))
            unit = match.group(2)
            if unit == 'month':
                time_range = timedelta(days=num*30)
            elif unit == 'week':
                time_range = timedelta(weeks=num)
            elif unit == 'day':
                time_range = timedelta(days=num)
        return time_range

    # Function to interact with PandasAI
    def chat_with_csv(df, prompt):
        llm = OpenAI(api_token=openai_api_key)
        smart_df = SmartDataframe(df)
        result = smart_df.chat(enhance_prompt(prompt))
        return result

    # Function to plot trends
    def plot_trends(df, date_col, rating_col, time_range=None):
        df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        if time_range:
            cutoff_date = datetime.now() - time_range
            df = df[df[date_col] >= cutoff_date]

        trend_data = df.groupby(df[date_col].dt.to_period("M"))[rating_col].mean().reset_index()
        trend_data[date_col] = trend_data[date_col].dt.to_timestamp()

        plt.figure(figsize=(10, 6))
        sns.lineplot(x=trend_data[date_col], y=trend_data[rating_col], marker='o')
        plt.title(f"Average {rating_col} Over Time", fontsize=16)
        plt.xlabel("Date", fontsize=12)
        plt.ylabel(f"Average {rating_col}", fontsize=12)
        plt.xticks(rotation=45)
        plt.grid(True)
        st.pyplot(plt)

    # Function to perform sentiment analysis
    def sentiment_analysis(df, sentiment_col='Aspect_Sentiment', time_range=None):
        if time_range:
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
            cutoff_date = datetime.now() - time_range
            df = df[df['date'] >= cutoff_date]

        sentiment_counts = df[sentiment_col].value_counts()

        plt.figure(figsize=(8, 5))
        sns.barplot(x=sentiment_counts.index, y=sentiment_counts.values, palette='viridis')
        plt.title(f"Sentiment Distribution", fontsize=16)
        plt.xlabel("Sentiment", fontsize=12)
        plt.ylabel("Frequency", fontsize=12)
        plt.grid(True)
        st.pyplot(plt)

    # Streamlit app configuration
    #st.set_page_config(layout='wide', page_title="ChatCSV powered by LLM", initial_sidebar_state="expanded")

    # Updated CSS styles

    # Title and introductory text
    st.markdown("<h1 class='stTitle'>FaysalBank ChatBot</h1>", unsafe_allow_html=True)
    st.write("Enter your query below to interact with the data.")

    # File uploader for CSV input
    input_csv = st.file_uploader("Upload your CSV file", type=['csv'])

    # Ensure CSV data is uploaded and cleaned before allowing interactions
    if input_csv is not None:
        data = pd.read_csv(input_csv)
        cleaned_data = clean_data(data)

        # Display cleaned data as a collapsible section
        with st.expander("📊 View Uploaded Data", expanded=False):
            st.dataframe(cleaned_data, use_container_width=True, height=400)

        # Chat interface for queries
        input_text = st.text_area("Query", placeholder="Ask a question about the data (e.g., 'Show average rating of reviews')")

        # Process query only if CSV is uploaded and cleaned
        if input_text and st.button("Chat"):
            st.info("Your Query: " + input_text)
            result = chat_with_csv(cleaned_data, input_text)
            st.success(result)

        # Trend analysis based on user query
        if 'trend' in input_text.lower():
            time_range = parse_time_range(input_text)
            st.subheader("Trend Analysis")
            st.info(f"Plotting trends for the last {time_range.days if time_range else 'all'} days...")
            plot_trends(cleaned_data, 'date', 'rating', time_range)

        # Sentiment analysis based on user query
        if 'sentiment' in input_text.lower():
            time_range = parse_time_range(input_text)
            st.subheader("Sentiment Analysis")
            st.info(f"Plotting sentiment distribution for the last {time_range.days if time_range else 'all'} days...")
            sentiment_analysis(cleaned_data, time_range=time_range)
    else:
        st.warning("Please upload a CSV file first.")

def churn_analysis():
    customer_churn_data = pd.read_csv('churn_predictions.csv')

    st.title("Bank Customer Churn Prediction")

    safeThreshold = 0.25
    neturalThreshold = 0.5
    moderateThreshold = 0.65
    riskyThreshold = 0.85

    def get_churn_risk(churn_probability):
        if churn_probability < safeThreshold:
            return "Loyal Customers"
        elif churn_probability < neturalThreshold:
            return "Safe"
        elif churn_probability < moderateThreshold:
            return "May Leave"
        elif churn_probability < riskyThreshold:
            return "Risky"
        else:
            return "Very Risky"
        
    def get_churn_color(churn_probability):
        if churn_probability < safeThreshold:
            return "#007378"  # Teal Green
        elif churn_probability < neturalThreshold:
            return "#4A4A4A"  # Dark Gray
        elif churn_probability < moderateThreshold:
            return "#D3D3D3"  # Light Gray
        elif churn_probability < riskyThreshold:
            return "#1A3B8E"  # Blue
        else:
            return "#5FB7B7"  # Turquoise/Light Teal
        
    customer_dict = {}
    for _, row in customer_churn_data.iterrows():
        customer_ID = row['customer_id']
        churn_prediction = row['churn_prediction']
        churn_risk = get_churn_risk(row['churn_probability'])
        churn_color = get_churn_color(row['churn_probability'])
        customer_data = {
            'churn_prediction': churn_prediction,
            'churn_risk': churn_risk,
            'churn_color': churn_color
        }
        customer_dict[customer_ID] = customer_data
    plt.style.use('dark_background')

    risk_levels = ["Loyal Customers", "Safe", "May Leave", "Risky", "Very Risky"]
    risk_counts = defaultdict(int)
    risk_colors = {
        "Loyal Customers": "#4A4A4A",  # Teal Green
        "Safe": "#007378",  # Dark Gray
        "May Leave": "#D3D3D3",  # Light Gray
        "Risky": "#1A3B8E",  # Blue
        "Very Risky": "#5FB7B7"  # Turquoise/Light Teal
    }

    for customer_data in customer_dict.values():
        risk_counts[customer_data['churn_risk']] += 1

    fig, ax = plt.subplots()
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    bars = ax.bar(risk_levels, [risk_counts[risk] for risk in risk_levels], color=[risk_colors[risk] for risk in risk_levels])

    ax.set_xlabel('Risk Factor', fontweight='bold')
    ax.set_ylabel('Number of Customers', fontweight='bold')
    ax.set_title('Number of Customers by Risk Factor')

    tab1, tab2 = st.tabs(["Overall Churn Graph", "Individual Customer Churn Prediction"])

    with tab1:
        st.pyplot(fig)

    with tab2:
        st.header('Enter Customer Details')

        customer_id = st.text_input('Customer ID')
        age = st.number_input('Age', min_value=18, max_value=100, step=1)
        balance = st.number_input('Account Balance', min_value=0.0, step=0.01)
        num_of_products = st.number_input('Number of Products', min_value=1, max_value=10, step=1)
        has_cr_card = st.selectbox('Has Credit Card?', ['Yes', 'No'])
        is_active_member = st.selectbox('Is Active Member?', ['Yes', 'No'])
        estimated_salary = st.number_input('Estimated Salary', min_value=0.0, step=0.01)
        tenure = st.number_input('Tenure', min_value=0, step=1)
        credit_score = st.number_input('Credit Score', min_value=300, max_value=850, step=1)
        gender = st.selectbox('Gender', ['Male', 'Female'])
        city = st.selectbox('City', ['Karachi', 'Islamabad', 'Quetta'])

        if st.button('Predict Churn'):
            customer_data = {
                'customer_id': customer_id,
                'credit_score': credit_score,
                'city': city,
                'gender': gender,
                'age': age,
                'tenure': tenure,
                'balance': balance,
                'products_number': num_of_products,
                'credit_card': 1 if has_cr_card == 'Yes' else 0,
                'active_member': 1 if is_active_member == 'Yes' else 0,
                'estimated_salary': estimated_salary,
            }
            
            churn_probability = model_pipeline.predict_proba(pd.DataFrame([customer_data]))[0][1]
            churn_risk = get_churn_risk(churn_probability)
            churn_color = get_churn_color(churn_probability)
            
            st.write(f"Churn Probability: {churn_probability:.2f}")
            st.write(f"Churn Risk: {churn_risk}")
            if churn_risk == "Loyal Customers":
                st.write("This customer is a loyal customer and is not likely to churn.")
            elif churn_risk == "Safe":
                st.write("This customer is somewhat safe and is not likely to churn.")
            elif churn_risk == "May Leave":
                st.write("This customer may leave the bank.")
            elif churn_risk == "Risky":
                st.write("This customer is at high risk of leaving the bank.")

    
# Adjusted filter_data function with checks for 'score' column and rating validation
def filter_data(data, start_date, end_date, min_rating, max_rating):
    # Validate rating range
    if max_rating < min_rating:
        return data  # Return unfiltered data if rating range is invalid

    # Identify and use the correct date column name
    if 'at' in data.columns:
        date_column = 'at'
    elif 'date' in data.columns:
        date_column = 'date'
    elif 'created_at' in data.columns:
        date_column = 'created_at'
    else:
        st.error("No suitable date column found in data.")
        return data  # Return unfiltered data if date column is missing

    # Convert the identified date column to datetime
    data['date'] = pd.to_datetime(data[date_column], errors='coerce')

    # Check if 'score' or 'rating' column exists for filtering by rating
    if 'score' in data.columns:
        rating_column = 'score'
    elif 'rating' in data.columns:
        rating_column = 'rating'
    else:
        st.error("No suitable rating column found in data.")
        return data  # Return unfiltered data if rating column is missing

    # Filter data based on selected date range and minimum rating
    data = data[(data['date'] >= pd.to_datetime(start_date)) & (data['date'] <= pd.to_datetime(end_date))]
    data = data[data[rating_column] >= min_rating]
    data = data[data[rating_column] <= max_rating]

    return data

# Main dashboard function with tabs and close functionality
def main():
    st.title("Faysal Bank Reviews Dashboard")

    # Custom CSS to change slider and radio button color
    st.markdown("""
        <style>
            .css-1lcbmhc {
                background-color: #6a0dad !important;  /* Purple slider track */
            }
            .stRadio button {
                background-color: #6a0dad !important;  /* Purple radio button */
            }
            .css-1cpxqw2 {  /* Sliders */
                color: #6a0dad !important;
            }
        </style>
        """, unsafe_allow_html=True)

    # Initialize data variables
    data, data_meezan = None, None

    # Load and filter data
    playstore_data, appstore_data = load_data()
    playstore_data_meezan, appstore_data_meezan = load_data_meezan()
    playstore_data_soneri, appstore_data_soneri = load_data_soneri()
    
    # Sidebar tab selection
    selected_tab = st.sidebar.radio("Select a Tab:", ["App Analysis", "Branch Analysis", "ChatBot", "Churn Analysis"])

    # Sidebar content based on selected tab
    with st.sidebar:
        if selected_tab == "App Analysis":
            st.write("### Filter Options")
            start_date = st.date_input("Start Date", datetime(2020, 1, 1))
            end_date = st.date_input("End Date", datetime.now())
            store_option = st.selectbox("Select App Store", ["Both", "Play Store", "App Store"])
            min_rating = st.slider("Minimum Rating", 1, 5, 1)
            max_rating = st.slider("Maximum Rating", 1, 5, 5)
            view_type = st.radio("Select View Type:", ("Monthly", "Yearly"))
            compete = st.radio("Competitive Analysis", ("Disable", "Enable"))
            if max_rating < min_rating:
                st.warning("Maximum rating cannot be lower than minimum rating. Please adjust the filter.")

            # Apply filters to data
            if store_option in ["Both", "Play Store"]:
                playstore_data = filter_data(playstore_data, start_date, end_date, min_rating, max_rating)
                playstore_data_meezan = filter_data(playstore_data_meezan, start_date, end_date, min_rating, max_rating)
                playstore_data_soneri = filter_data(playstore_data_soneri, start_date, end_date, min_rating, max_rating)
            if store_option in ["Both", "App Store"]:
                appstore_data = filter_data(appstore_data, start_date, end_date, min_rating, max_rating)
                appstore_data_meezan = filter_data(appstore_data_meezan, start_date, end_date, min_rating, max_rating)
                appstore_data_soneri = filter_data(appstore_data_soneri, start_date, end_date, min_rating, max_rating)

            # Combine filtered data for unified analysis
            if store_option == "Both":
                data = pd.concat([playstore_data, appstore_data], ignore_index=True)
                data_meezan = pd.concat([playstore_data_meezan, appstore_data_meezan], ignore_index=True)
                data_soneri = pd.concat([playstore_data_soneri, appstore_data_soneri], ignore_index=True)
            elif store_option == "Play Store":
                data = playstore_data
                data_meezan = playstore_data_meezan
                data_soneri = playstore_data_soneri
            else:
                data = appstore_data
                data_meezan = appstore_data_meezan
                data_soneri = appstore_data_soneri

        elif selected_tab == "Branch Analysis":
            st.write("### Branch Analysis Settings")
            # Add branch-specific filter options here

        elif selected_tab == "ChatBot":
            st.write("### ChatBot Options")
            # Add chatbot-specific settings here

        elif selected_tab == "Churn Analysis":
            st.write("### Churn Analysis Options") # Add chatbot-specific settings here

    # Main content based on selected tab
    if selected_tab == "App Analysis":
        st.write("## App Analysis")
        
        # Create sub-tabs for the App Analysis section
        sub_tab1, sub_tab2, sub_tab3, sub_tab4 = st.tabs(
            ["Timeline of Average Ratings", "Sentiment Analysis", "Word Cloud", "Rating Distribution"]
        )
        
        with sub_tab1:
            st.header("Timeline of Average Ratings")
            if data is not None and data_meezan is not None and data_soneri is not None:
                display_ratings_timeline(data, view_type, data_meezan, data_soneri, compete)
            else:
                st.warning("No data available. Please adjust the filters.")

        with sub_tab2:
            st.header("Sentiment Analysis")
            perform_sentiment_analysis(compete)

        with sub_tab3:
            st.header("Faysal Bank Word Cloud")
            if data is not None:
                st.pyplot(generate_word_cloud(data))
                if compete == "Enable":
                    if data_meezan is not None:
                        st.header("Meezan Bank Word Cloud")
                        st.pyplot(generate_word_cloud(data_meezan))
                    if data_soneri is not None:
                        st.header("Soneri Bank Word Cloud")
                        st.pyplot(generate_word_cloud(data_soneri))

        with sub_tab4:
            st.header("Rating Distribution")
            if data is not None:
                plot_rating_distribution(data, data_meezan, data_soneri, compete)

    elif selected_tab == "Branch Analysis":
        st.write("## Branch Analysis")
        map_analysis()

    elif selected_tab == "ChatBot":
        st.write("## ChatBot")
        chatbot()
    
    elif selected_tab == "Churn Analysis":
        st.write("## Churn Analysis")
        churn_analysis()

# Run main function
if __name__ == "__main__":
    main()
