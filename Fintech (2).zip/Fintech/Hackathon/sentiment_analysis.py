from transformers import pipeline
import re
from transformers import BertTokenizer, BertForSequenceClassification
import spacy
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from collections import Counter
import csv
import matplotlib.pyplot as plt
import pandas as pd
import os


tokenizer = BertTokenizer.from_pretrained('yiyanghkust/finbert-tone')
model = BertForSequenceClassification.from_pretrained('yiyanghkust/finbert-tone')

sentiment_pipeline = pipeline("sentiment-analysis", model=model, tokenizer=tokenizer)
nlp = spacy.load("en_core_web_sm")
sentiment_analyzer = SentimentIntensityAnalyzer()


aspects_list = ["loan", "account", "support", "service", "security", "bank", "staff", "payment", "branch", "services", "rude", "behaviour", "customer", "atm" ]

branches_data = pd.read_csv("info.csv")
reviews_data = pd.read_csv("r.csv")

meezan_branches = pd.read_csv("m_info.csv")
meezan_reviews = pd.read_csv("m_r.csv")

soneri_branches = pd.read_csv("s_info.csv")
soneri_reviews = pd.read_csv("s_r.csv")

def extract_aspects(text):
    # Convert to lowercase
    try:
        text = text.lower()
        # Remove punctuation
        text = re.sub(r'[^\w\s]', '', text)
        # Remove numbers
        text = re.sub(r'\d+', '', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
        doc = nlp(text.lower())
    except:
        return []
    aspects = []
    for chunk in doc.noun_chunks:
        aspect = chunk.root.text
        if aspect in aspects_list:  # Filter based on predefined aspects
            aspects.append(aspect)
    return aspects

def get_aspect_sentiment(text, aspect):
    # Convert to lowercase
    try:
        text = text.lower()
        # Remove punctuation
        text = re.sub(r'[^\w\s]', '', text)
        # Remove numbers
        text = re.sub(r'\d+', '', text)
        # Remove extra whitespace
        text = ' '.join(text.split())
    except:
        pass

    sentences = text.split('.')
    for sentence in sentences:
        if aspect.lower() in sentence.lower():
            # Get sentiment predictions from BERT
            sentiment_result = sentiment_pipeline(sentence)
            sentiment = sentiment_result[0]['label']
            # Convert BERT's sentiment label to your project's format
            if "positive" in sentiment.lower():
                return "positive"
            elif "negative" in sentiment.lower():
                return "negative"
            else:
                return "neutral"
    return "neutral"

def analyze_review(review):
    review_data = {"review": review, "aspects": [], "sentiments": []}
    aspects = extract_aspects(review)
    for aspect in aspects:
        sentiment = get_aspect_sentiment(review, aspect)
        review_data["aspects"].append(aspect)
        review_data["sentiments"].append((aspect, sentiment))
    return review_data

def dict_from_review(review_data):
    aspect_sentiment_counts = {aspect: {"positive": 0, "negative": 0, "neutral": 0} for aspect in aspects_list}
    
    if "sentiments" in review_data:
        for aspect, sentiment in review_data["sentiments"]:
            if aspect in aspect_sentiment_counts:
                aspect_sentiment_counts[aspect][sentiment] += 1
    
    return aspect_sentiment_counts

def create_reviews_dict(reviews_data):
    reviews_dict = {}
    
    for _, row in reviews_data.iterrows():
        branch_id = row['BranchID']
        review = row['Reviews']
        
        if branch_id not in reviews_dict:
            reviews_dict[branch_id] = []
        
        reviews_dict[branch_id].append(review)
    
    
    return reviews_dict

def analyze_reviews_and_store(reviews, branch_id, branch_name, output_file):
    all_reviews_data = []
    
    for review in reviews:
        review_data = analyze_review(review)
        review_data["BranchID"] = branch_id
        review_data["Name"] = branch_name
        all_reviews_data.append(review_data)
    
    with open(output_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["BranchID", "Name", "review", "aspect", "sentiment"])
        
        for review_data in all_reviews_data:
            for aspect, sentiment in review_data["sentiments"]:
                writer.writerow([review_data["BranchID"], review_data["Name"], review_data["review"], aspect, sentiment])

    return all_reviews_data

def word_count_csv(reviews, output_file):
    word_dict = {}
    for _, rev in reviews.iterrows():
        try:
            words = rev['Reviews'].split()
            for word in words:
                if word in word_dict:
                    word_dict[word] += 1
                else:
                    word_dict[word] = 1
        except:
            pass
    #writing the dict to csv
    with open(output_file, mode='w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerow(["Word", "Count"])
        for word, count in word_dict.items():
            writer.writerow([word, count])

def convert_csv_to_excel(input_file, output_file):
    files_to_convert = [
        (input_file, output_file),
    ]

    for csv_file_path, excel_file_path in files_to_convert:
        if os.path.exists(csv_file_path):
            df = pd.read_csv(csv_file_path)
            df.to_excel(excel_file_path, index=False)
            print(f"Converted {csv_file_path} to {excel_file_path}")
        else:
            print(f"File not found: {csv_file_path}")

def count_of_sentiments(reviews):
    sentiment_count = {"positive": 0, "negative": 0, "neutral": 0}
    for _, rev in reviews.iterrows():
        try:
            sentiment = sentiment_analyzer.polarity_scores(rev['Reviews'])
            if sentiment['compound'] >= 0.05:
                sentiment_count["positive"] += 1
            elif sentiment['compound'] <= -0.05:
                sentiment_count["negative"] += 1
            else:
                sentiment_count["neutral"] += 1
        except:
            pass
    return sentiment_count



reviews_dict = create_reviews_dict(soneri_reviews)
print(reviews_dict)
for branch_id, reviews in reviews_dict.items():
    branch_row = branches_data[branches_data["BranchID"] == branch_id]
    if not branch_row.empty:
        branch_name = branch_row["Name"].values[0]
    else:
        branch_name = "Unknown"
    analyze_reviews_and_store(reviews, branch_id, branch_name, f"s_reviews/reviews_{branch_id}.csv")

word_count_csv(soneri_reviews, "s_word_count.csv")
convert_csv_to_excel("s_word_count.csv", "s_word_count.xlsx")