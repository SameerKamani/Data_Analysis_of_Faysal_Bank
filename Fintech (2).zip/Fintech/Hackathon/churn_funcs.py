import pandas as pd
from collections import defaultdict
from churn_predictor import model_pipeline


customer_data = pd.read_csv('Bank Customer Churn Prediction Extended.csv')



def create_datalist_from_csv(data):
    data_list = []
    for index, d in data.iterrows():
        ID = d['customer_id']
        credit_score = d['credit_score']
        city = d['city']
        gender = d['gender']
        age = d['age']
        tenure = d['tenure']
        balance = d['balance']
        products_number = d['products_number']
        credit_card = d['credit_card']
        active_member = d['active_member']
        estimated_salary = d['estimated_salary']
        
        temp_data = pd.DataFrame({
            'customer_id': [ID],
            'credit_score': [credit_score],
            'city': [city],
            'gender': [gender],
            'age': [age],
            'tenure': [tenure],
            'balance': [balance],
            'products_number': [products_number],
            'credit_card': [credit_card],
            'active_member': [active_member],
            'estimated_salary': [estimated_salary]
        })

        data_list.append(temp_data)
    return data_list

def csv_from_datalist(data_list):
    for i in data_list:
        prediction = model_pipeline.predict(i)
        churn_probability = model_pipeline.predict_proba(i)[0][1]
        churn_info = {
            'customer_id': i['customer_id'].values[0],
            'churn_prediction': prediction[0],
            'churn_probability': churn_probability
        }
        churn_df = pd.DataFrame([churn_info])
        churn_df.to_csv('churn_predictions.csv', mode='a', header=not pd.io.common.file_exists('churn_predictions.csv'), index=False)

data_list = create_datalist_from_csv(customer_data)
csv_from_datalist(data_list)


