# Appstre_reviews.py
from google_play_scraper import Sort, reviews
from app_store_scraper import AppStore
import pandas as pd
import spacy
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from collections import Counter
import matplotlib.pyplot as plt

from transformers import pipeline
import re

# Load the tokenizer and model for ABSA
from transformers import BertTokenizer, BertForSequenceClassification

tokenizer = BertTokenizer.from_pretrained('yiyanghkust/finbert-tone')
model = BertForSequenceClassification.from_pretrained('yiyanghkust/finbert-tone')


sentiment_pipeline = pipeline("sentiment-analysis", model=model, tokenizer=tokenizer)

# Initialize spaCy model for NLP
nlp = spacy.load("en_core_web_sm")

sentiment_analyzer = SentimentIntensityAnalyzer()

# Define service categories and expanded keywords (remains unchanged)
service_keywords = {
    "Loan Service": ["loan", "credit", "financing", "loan process", "interest rate"],
    "Customer Support": ["support", "help", "service", "complaint", "issue", "response", "contact"],
    "App Performance": ["slow", "bug", "crash", "loading", "error", "lag", "freeze", "unresponsive"],
    "Account Management": ["account", "balance", "transaction", "transfer", "deposit", "withdrawal"],
    "Security": ["secure", "password", "privacy", "authentication", "otp", "two-factor"],
    "User Experience": ["interface", "navigation", "user-friendly", "confusing", "easy to use", "intuitive", "design"],
    "Technical Issues": ["doesn't work", "not working", "needs improvement", "update", "fix", "problem", "broken"],
    "Notifications": ["notification", "alert", "reminder", "missed", "pop-up"],
    "Payment Processing": ["payment", "bills", "transaction failure", "payment error", "gateway"]
}

# Function to categorize a single review and include the reason (remains unchanged)
def categorize_review(text):
    doc = nlp(text.lower())
    categories = {}
    
    for category, keywords in service_keywords.items():
        matched_keywords = [keyword for keyword in keywords if keyword in doc.text]
        if matched_keywords:
            categories[category] = matched_keywords

    if categories:
        category_list = ", ".join(categories.keys())
        reasons = ", ".join([f"{cat}: {', '.join(reasons)}" for cat, reasons in categories.items()])
        return category_list, reasons
    else:
        return "Other", "No specific keywords matched"
    


# Extract aspects using spaCy
aspects_list = ["loan", "account", "support", "service", "app", "account", "security", "interface", "notification", "payment", "otp" ]

def extract_aspects(text):
    
    # Convert to lowercase
    text = text.lower()
    # Remove punctuation
    text = re.sub(r'[^\w\s]', '', text)
    # Remove numbers
    text = re.sub(r'\d+', '', text)
    # Remove extra whitespace
    text = ' '.join(text.split())
    doc = nlp(text.lower())
    aspects = []
    for chunk in doc.noun_chunks:
        aspect = chunk.root.text
        if aspect in aspects_list:  # Filter based on predefined aspects
            aspects.append(aspect)
    return aspects

def get_aspect_sentiment(text, aspect):
    # Convert to lowercase
    text = text.lower()
    # Remove punctuation
    text = re.sub(r'[^\w\s]', '', text)
    # Remove numbers
    text = re.sub(r'\d+', '', text)
    # Remove extra whitespace
    text = ' '.join(text.split())

    sentences = text.split('.')
    for sentence in sentences:
        if aspect.lower() in sentence.lower():
            # Get sentiment predictions from BERT
            sentiment_result = sentiment_pipeline(sentence)
            sentiment = sentiment_result[0]['label']
            # Convert BERT's sentiment label to your project's format
            if "positive" in sentiment.lower():
                return "positive"
            elif "negative" in sentiment.lower():
                return "negative"
            else:
                return "neutral"
    return "neutral"

def analyze_review(review):
    review_data = {"review": review, "aspects": [], "sentiments": []}
    aspects = extract_aspects(review)
    for aspect in aspects:
        sentiment = get_aspect_sentiment(review, aspect)
        review_data["aspects"].append(aspect)
        review_data["sentiments"].append((aspect, sentiment))
    return review_data

def dict_from_review(review_data):
    aspect_sentiment_counts = {aspect: {"positive": 0, "negative": 0, "neutral": 0} for aspect in aspects_list}
    
    if "sentiments" in review_data:
        for aspect, sentiment in review_data["sentiments"]:
            if aspect in aspect_sentiment_counts:
                aspect_sentiment_counts[aspect][sentiment] += 1
    
    return aspect_sentiment_counts


# Function to count words from reviews and save to CSV
def count_words_and_save_to_csv(reviews, output_csv_path):
    # Combine all reviews into one string
    all_reviews = " ".join(reviews)
    
    # Tokenize and count words
    words = all_reviews.lower().split()
    word_counts = Counter(words)
    
    # List of common words to ignore
    common_words = set([
        "i", "the", "is", "it", "they", "a", "an", "and", "or", "but", "if", "in", "on", "at", "by", "for", "with", 
        "about", "as", "to", "of", "from", "that", "this", "these", "those", "are", "was", "were", "be", "been", 
        "being", "have", "has", "had", "do", "does", "did", "will", "would", "can", "could", "should", "shall", 
        "may", "might", "must", "not", "no", "yes", "you", "we", "he", "she", "him", "her", "them", "us", "our", 
        "your", "their", "its", "which", "who", "whom", "whose", "how", "what", "when", "where", "why", "all", 
        "any", "some", "many", "most", "few", "more", "less", "such", "only", "own", "same", "so", "than", "too", 
        "very", "just", "now", "then", "again", "once", "here", "there", "still", "yet", "ever", "never", "always", 
        "sometimes", "usually", "often", "seldom", "rarely", "almost", "quite", "really", "actually", "probably", 
        "maybe", "perhaps", "sure", "certain", "likely", "unlikely", "possible", "impossible", "able", "unable"
    ])
    
    # Filter out common words and words with count less than 100
    filtered_word_counts = {word: count for word, count in word_counts.items() if count >= 100 and word not in common_words}
    
    # Convert filtered word counts to DataFrame
    word_counts_df = pd.DataFrame(filtered_word_counts.items(), columns=['Word', 'Count'])
    
    # Save filtered word counts to CSV
    word_counts_df.to_csv(output_csv_path, index=False)
    print(f"Filtered word counts saved to {output_csv_path}")

# Fetch Google Play Store reviews (remains unchanged)
def fetch_playstore_reviews_fb():
    app_id = 'com.avanza.ambitwizfbl'
    result, _ = reviews(app_id, lang='en', country='pk', sort=Sort.MOST_RELEVANT, count=23000)
    df = pd.DataFrame(result)
    
    # Apply categorization function
    df[['Category', 'Reason']] = df['content'].apply(lambda x: pd.Series(categorize_review(x)))

    # Perform aspect-based sentiment analysis
    df['Aspect_Sentiment'] = df['content'].apply(lambda x: analyze_review(x))

    # Create a dictionary to store sentiment counts
    sentiment_counts = {aspect: {"positive": 0, "negative": 0, "neutral": 0} for aspect in aspects_list}
    
    # Update sentiment counts based on the reviews
    for review_data in df['Aspect_Sentiment']:
        aspect_sentiment_counts = dict_from_review(review_data)
        for aspect, sentiments in aspect_sentiment_counts.items():
            for sentiment, count in sentiments.items():
                sentiment_counts[aspect][sentiment] += count
    
    # Convert sentiment counts to DataFrame
    sentiment_counts_df = pd.DataFrame(sentiment_counts).T.reset_index()
    sentiment_counts_df.columns = ['Aspect', 'Positive', 'Negative', 'Neutral']

    # Save sentiment counts to CSV
    sentiment_counts_df.to_csv('playstore_sentiment_counts.csv', index=False)
    print("Sentiment counts saved to playstore_sentiment_counts.csv")
    
    # Save sentiment counts to CSV
    sentiment_counts_df.to_csv('playstore_sentiment_counts.csv', index=False)
    print("Sentiment counts saved to playstore_sentiment_counts.csv")

    # Count words and save to CSV
    count_words_and_save_to_csv(df['content'].tolist(), 'playstore_word_counts.csv')
    
    # Save categorized reviews and aspect sentiment analysis to CSV
    df.to_csv('faisal_digibank_playstore_reviews.csv', index=False)
    print("Fetched, categorized, and saved Play Store reviews with reasons and aspect sentiment analysis.")

def fetch_appstore_reviews_fb():
    faysal = AppStore(country="pk", app_name="faysal-digibank", app_id="1459836486")
    try:
        faysal.review(how_many=2000)
    except Exception as e:
        print(f"An error occurred: {e}")
    df = pd.DataFrame(faysal.reviews)
    
    # Apply categorization function
    df[['Category', 'Reason']] = df['review'].apply(lambda x: pd.Series(categorize_review(x)))
    
    # Perform aspect-based sentiment analysis
    df['Aspect_Sentiment'] = df['review'].apply(lambda x: analyze_review(x))

    # Create a dictionary to store sentiment counts
    sentiment_counts = {aspect: {"positive": 0, "negative": 0, "neutral": 0} for aspect in aspects_list}

    # Update sentiment counts based on the reviews
    for review_data in df['Aspect_Sentiment']:
        aspect_sentiment_counts = dict_from_review(review_data)
        for aspect, sentiments in aspect_sentiment_counts.items():
            for sentiment, count in sentiments.items():
                sentiment_counts[aspect][sentiment] += count

    # Convert sentiment counts to DataFrame
    sentiment_counts_df = pd.DataFrame(sentiment_counts).T.reset_index()
    sentiment_counts_df.columns = ['Aspect', 'Positive', 'Negative', 'Neutral']

    # Save sentiment counts to CSV
    sentiment_counts_df.to_csv('appstore_sentiment_counts.csv', index=False)
    print("Sentiment counts saved to appstore_sentiment_counts.csv")
    
    # Count words and save to CSV
    count_words_and_save_to_csv(df['review'].tolist(), 'appstore_word_counts.csv')
    
    # Save categorized reviews and aspect sentiment analysis to CSV
    df.to_csv('faysal_digibank_appstore_reviews.csv', index=False)
    print("Fetched, categorized, and saved App Store reviews with reasons and aspect sentiment analysis.")
